using System.Collections.Generic;
public class KeyInfoList
{
    public List<KeyInfo> keyInfos;
}
